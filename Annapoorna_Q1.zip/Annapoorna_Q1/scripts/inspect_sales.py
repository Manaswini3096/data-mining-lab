from pathlib import Path
from collections import Counter

SALES_DIR = Path("data/sales")

# Find all files
files = [f for f in SALES_DIR.rglob("*") if f.is_file()]

# Separate file types
csv_files = [f for f in files if f.suffix.lower() == ".csv"]
parquet_files = [f for f in files if f.suffix.lower() == ".parquet"]

# Resend files
resend_files = [f for f in files if "__R" in f.stem]

# Count files by store
stores = Counter()

for f in files:
    parts = f.stem.split("_")

    if len(parts) >= 2 and parts[0].upper() == "SALES":
        stores[parts[1]] += 1

# Total size
total_bytes = sum(f.stat().st_size for f in files)

print("=" * 60)
print("ANNAPOORNA SALES DATA INSPECTION")
print("=" * 60)

print(f"Sales directory : {SALES_DIR}")
print(f"Total files     : {len(files)}")
print(f"CSV files       : {len(csv_files)}")
print(f"Parquet files   : {len(parquet_files)}")
print(f"Resend files    : {len(resend_files)}")
print(f"Total bytes     : {total_bytes:,}")

print("\nFILES BY STORE")
print("-" * 60)

for store, count in sorted(stores.items()):
    print(f"{store}: {count}")

print("\nRESEND FILE EXAMPLES")
print("-" * 60)

for f in sorted(resend_files)[:20]:
    print(f.name)

print("\nFIRST 20 SALES FILES")
print("-" * 60)

for f in sorted(files)[:20]:
    print(f.name)

print("\nINSPECTION COMPLETE")
print("=" * 60)