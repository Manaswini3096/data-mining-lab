from pathlib import Path
import pandas as pd
import hashlib
import re
import shutil

# ---------------------------------------------------------
# PATHS
# ---------------------------------------------------------

INPUT_DIR = Path("data/sales")
OUTPUT_DIR = Path("data/normalized/sales")
REPORT_DIR = Path("output/Part_B")

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------
# FILE INFORMATION
# ---------------------------------------------------------

def get_store_from_filename(filename):
    """
    Extract store from:
    SALES_S01_20240101.csv
    SALES_S01_20240101__R1.csv
    """

    match = re.search(r"SALES_(S\d+)_", filename.upper())

    if match:
        return match.group(1)

    return None


def get_date_from_filename(filename):
    """
    Extract YYYYMMDD from filename.
    """

    match = re.search(r"_(\d{8})(?:__R\d+)?\.", filename)

    if match:
        return pd.to_datetime(
            match.group(1),
            format="%Y%m%d"
        )

    return None


# ---------------------------------------------------------
# READ CSV
# ---------------------------------------------------------

def read_csv_file(path):

    store = get_store_from_filename(path.name)
    file_date = get_date_from_filename(path.name)

    # Read first line to determine whether there is a header
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        first_line = f.readline().strip()

    # S06-S09 use semicolon
    if ";" in first_line:
        df = pd.read_csv(
            path,
            sep=";",
            dtype=str
        )

        # Standardize column names
        df = df.rename(columns={
            "item_code": "product_code",
            "rate": "unit_price",
            "type": "line_type",
            "txn_time": "timestamp"
        })

    else:
        # Determine whether this is S01-S05 or S10-S12
        if first_line.startswith("ts,"):
            # S10-S12 have a header
            df = pd.read_csv(
                path,
                dtype=str
            )

            df = df.rename(columns={
                "ts": "source_ts",
                "line_type": "line_type",
                "product_code": "product_code",
                "unit_price": "unit_price",
                "qty": "quantity",
                "bill_no": "bill_no",
                "line_no": "line_no"
            })

        else:
            # S01-S05 have no header
            df = pd.read_csv(
                path,
                header=None,
                names=[
                    "bill_no",
                    "line_no",
                    "product_code",
                    "quantity",
                    "unit_price",
                    "line_type",
                    "timestamp"
                ],
                dtype=str
            )

    # Add store and source file
    df["store_id"] = store
    df["source_file"] = path.name

    # If S10 timestamp is not present, derive timestamp from Unix timestamp
    if "timestamp" not in df.columns:

        if "source_ts" in df.columns:
            df["timestamp"] = pd.to_datetime(
                pd.to_numeric(
                    df["source_ts"],
                    errors="coerce"
                ),
                unit="s",
                errors="coerce"
            )

    # Parse timestamps
    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        errors="coerce",
        dayfirst=True
    )

    # If timestamp is missing, use filename date
    if file_date is not None:
        df["business_date"] = df["timestamp"].dt.date

        df["business_date"] = df["business_date"].fillna(
            file_date.date()
        )
    else:
        df["business_date"] = df["timestamp"].dt.date

    return df


# ---------------------------------------------------------
# READ PARQUET
# ---------------------------------------------------------

def read_parquet_file(path):

    store = get_store_from_filename(path.name)
    file_date = get_date_from_filename(path.name)

    df = pd.read_parquet(path)

    # Convert column names to lowercase
    df.columns = [str(c).lower() for c in df.columns]

    # Possible column-name variations
    rename_map = {
        "item_code": "product_code",
        "product": "product_code",
        "qty": "quantity",
        "rate": "unit_price",
        "price": "unit_price",
        "type": "line_type",
        "txn_time": "timestamp",
        "ts": "source_ts"
    }

    df = df.rename(columns=rename_map)

    # S10-style timestamp
    if "timestamp" not in df.columns and "source_ts" in df.columns:
        df["timestamp"] = pd.to_datetime(
            pd.to_numeric(
                df["source_ts"],
                errors="coerce"
            ),
            unit="s",
            errors="coerce"
        )

    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(
            df["timestamp"],
            errors="coerce"
        )

    df["store_id"] = store
    df["source_file"] = path.name

    if "timestamp" in df.columns:
        df["business_date"] = df["timestamp"].dt.date
    else:
        df["business_date"] = file_date.date()

    return df


# ---------------------------------------------------------
# STANDARDIZE DATA
# ---------------------------------------------------------

def standardize(df):

    required = [
        "bill_no",
        "line_no",
        "product_code",
        "quantity",
        "unit_price",
        "line_type",
        "timestamp",
        "store_id",
        "business_date",
        "source_file"
    ]

    for column in required:
        if column not in df.columns:
            df[column] = None

    # Clean text
    text_columns = [
        "bill_no",
        "line_no",
        "product_code",
        "line_type",
        "store_id",
        "source_file"
    ]

    for column in text_columns:
        df[column] = df[column].astype("string").str.strip()

    # Numeric columns
    df["quantity"] = pd.to_numeric(
        df["quantity"],
        errors="coerce"
    )

    df["unit_price"] = pd.to_numeric(
        df["unit_price"],
        errors="coerce"
    )

    # Standardize line type
    df["line_type"] = (
        df["line_type"]
        .astype("string")
        .str.upper()
        .str.strip()
    )

    # Revenue only for SALE lines
    df["is_sale"] = df["line_type"].eq("SALE")

    df["line_revenue"] = (
        df["quantity"] * df["unit_price"]
    )

    # Business date
    df["business_date"] = pd.to_datetime(
        df["business_date"],
        errors="coerce"
    ).dt.date

    return df[required + [
        "is_sale",
        "line_revenue"
    ]]


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

def main():

    files = sorted([
        f for f in INPUT_DIR.rglob("*")
        if f.is_file()
        and f.suffix.lower() in [".csv", ".parquet"]
    ])

    print("=" * 70)
    print("ANNAPOORNA SALES INGESTION")
    print("=" * 70)

    print(f"Input files found: {len(files)}")

    frames = []

    for i, path in enumerate(files, start=1):

        try:

            if path.suffix.lower() == ".csv":
                df = read_csv_file(path)
            else:
                df = read_parquet_file(path)

            df = standardize(df)

            frames.append(df)

            if i <= 10:
                print(
                    f"[OK] {path.name} -> {len(df)} rows"
                )

        except Exception as e:

            print(
                f"[ERROR] {path.name}: {e}"
            )

    if not frames:
        raise RuntimeError("No sales files could be read.")

    # Combine everything
    all_sales = pd.concat(
        frames,
        ignore_index=True
    )

    raw_rows = len(all_sales)

    print("\nRaw rows:", raw_rows)

    # -----------------------------------------------------
    # IDEMPOTENCY / DUPLICATE HANDLING
    # -----------------------------------------------------

    # A line is uniquely identified by store + bill + line.
    # Resend files therefore cannot create duplicate facts.

    all_sales["dedup_key"] = (
        all_sales["store_id"].astype(str)
        + "|"
        + all_sales["bill_no"].astype(str)
        + "|"
        + all_sales["line_no"].astype(str)
    )

    before_dedup = len(all_sales)

    all_sales = (
        all_sales
        .sort_values(
            ["dedup_key", "source_file"]
        )
        .drop_duplicates(
            subset=["dedup_key"],
            keep="first"
        )
        .reset_index(drop=True)
    )

    duplicate_rows = (
        before_dedup - len(all_sales)
    )

    print("Duplicate rows removed:", duplicate_rows)
    print("Rows after deduplication:", len(all_sales))

    # -----------------------------------------------------
    # WRITE PARTITIONED PARQUET
    # -----------------------------------------------------

    # Remove previous generated output so every run starts
    # from the same logical input.
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # Create year/month columns
    business_dates = pd.to_datetime(
        all_sales["business_date"]
    )

    all_sales["year"] = business_dates.dt.year
    all_sales["month"] = business_dates.dt.month

    # Partition by store/year/month
    for (store, year, month), group in all_sales.groupby(
        ["store_id", "year", "month"],
        dropna=False
    ):

        if pd.isna(year) or pd.isna(month):
            continue

        partition = (
            OUTPUT_DIR
            / f"store={store}"
            / f"year={int(year)}"
            / f"month={int(month):02d}"
        )

        partition.mkdir(
            parents=True,
            exist_ok=True
        )

        output_file = (
            partition
            / "sales.parquet"
        )

        group.to_parquet(
            output_file,
            index=False
        )

    # -----------------------------------------------------
    # CHECKSUM
    # -----------------------------------------------------

    # Stable checksum based on sorted deduplicated records.
    checksum_columns = [
        "store_id",
        "bill_no",
        "line_no",
        "product_code",
        "quantity",
        "unit_price",
        "line_type",
        "business_date"
    ]

    checksum_data = (
        all_sales[checksum_columns]
        .astype(str)
        .sort_values(checksum_columns)
        .to_csv(
            index=False,
            lineterminator="\n"
        )
        .encode("utf-8")
    )

    checksum = hashlib.sha256(
        checksum_data
    ).hexdigest()

    # -----------------------------------------------------
    # SUMMARY
    # -----------------------------------------------------

    sale_rows = int(
        all_sales["is_sale"].sum()
    )

    sale_revenue = float(
        all_sales.loc[
            all_sales["is_sale"],
            "line_revenue"
        ].sum()
    )

    print("\n" + "=" * 70)
    print("INGESTION RESULT")
    print("=" * 70)

    print(f"Raw rows              : {raw_rows}")
    print(f"Duplicate rows removed: {duplicate_rows}")
    print(f"Final rows             : {len(all_sales)}")
    print(f"SALE rows              : {sale_rows}")
    print(f"SALE revenue           : {sale_revenue:,.2f}")
    print(f"SHA256 checksum        : {checksum}")

    print("\nOutput:")
    print(OUTPUT_DIR)

    print("\nINGESTION COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()