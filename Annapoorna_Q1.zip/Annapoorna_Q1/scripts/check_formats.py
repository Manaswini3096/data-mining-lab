from pathlib import Path
import csv

SALES_DIR = Path("data/sales")

files = [
    "SALES_S01_20240101.csv",
    "SALES_S06_20240124.csv",
    "SALES_S10_20241122.csv",
]

for filename in files:
    path = SALES_DIR / filename

    print("\n" + "=" * 70)
    print(filename)
    print("=" * 70)

    if not path.exists():
        print("FILE NOT FOUND")
        continue

    # Read first few raw lines
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        lines = [next(f).rstrip("\n") for _ in range(5)]

    print("\nRAW FIRST 5 LINES:")
    for line in lines:
        print(line)

    # Detect delimiter
    sample = "\n".join(lines)

    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;|\t")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","

    print("\nDetected delimiter:", repr(delimiter))

    print("\nNumber of columns in first row:",
          len(lines[0].split(delimiter)))

    print("\nColumns/fields:")
    for i, value in enumerate(lines[0].split(delimiter), start=1):
        print(f"{i}: {value}")

print("\n" + "=" * 70)
print("FORMAT CHECK COMPLETE")
print("=" * 70)