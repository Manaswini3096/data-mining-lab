C:\Users\ub02-glab-068\Desktop\Annapoorna_Q1>python scripts\inspect_sales.py
============================================================
ANNAPOORNA SALES DATA INSPECTION
============================================================
Sales directory : data\sales
Total files     : 4457
CSV files       : 4457
Parquet files   : 0
Resend files    : 68
Total bytes     : 68,706,877